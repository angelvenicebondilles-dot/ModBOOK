# AGENTS.md — Business Entrepreneur  (Android)

You are helping a Jotform user get this app into Google Play. They are not a developer: explain in
plain words, one step at a time. Complete authorized local work and wait when the next step needs
the user's action.

## Build and publishing guidance
- Use the publish-mobile-app skill in .agents/skills/publish-mobile-app/SKILL.md (Codex) or
  .claude/skills/publish-mobile-app/SKILL.md (Claude Code) for setup, build, simulator or emulator
  testing, troubleshooting and store preparation. Both paths contain the same skill.
- Read README.md for this export's exact build requirements and hosted WebView limitation.
  Report build, runtime, signing and store submission as separate outcomes.

## What this project is
- A Capacitor Android project that opens the user's live Jotform app full screen.
- App name: Business Entrepreneur 
- Application ID: com.example.portal.app262654410770455
- Content edited in Jotform App Builder appears without a store update. A new name, icon or
  splash screen needs a fresh download from Jotform and a new store release.
  This app's download page: https://www.jotform.com/app/build/262654410770455/publish/mobile-app

## What you can settle here
- The Application ID above is a placeholder. Stores reject com.example IDs, and the ID can never
  change after the first upload, so set the user's own one before anything is uploaded.
- Use the set-app-identity skill (.claude/skills/set-app-identity, .agents/skills/set-app-identity)
  to change the name or the ID. Do not hand-edit them: they appear in several files.
- A new download from Jotform starts from the defaults above again. If the user already has a
  store listing, match its existing name and ID before building.

## What the user needs before publishing
- Android Studio with a current JDK. Any desktop operating system works.
- Node.js 22+ to run `npm ci` and `npm run open:android`.
- A Google Play Console developer account, plus their own signing credentials. The account,
  the fees and the submission stay with the user.

## Where the real instructions are
Store rules, fees and review times change, and they are the store's call, not Jotform's. Do not
recite them from memory: open the current page with the user.
- Publish your app — https://developer.android.com/studio/publish
- App signing — https://developer.android.com/studio/publish/app-signing
- Play Console — https://play.google.com/console/about/
- Capacitor Android — https://capacitorjs.com/docs/android
- Publishing a Jotform app to the stores — https://www.jotform.com/help/how-to-export-your-app-to-publish-on-google-play-and-apple-app-store/
- Jotform Apps help — https://www.jotform.com/help/jotform-apps/
- Jotform Apps for Claude — https://www.jotform.com/claude/app/
- Jotform Apps for ChatGPT — https://www.jotform.com/chatgpt/app/
  The last two build and edit Jotform apps from a chat. They do not publish to the stores,
  so use them only if the user wants to change the app itself.

See README.md for this project's build details.
