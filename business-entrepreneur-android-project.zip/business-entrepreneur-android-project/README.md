# Portal mobile project

## Start with Codex or Claude Code

Extract the ZIP and open the whole extracted project folder in Codex or Claude Code.
Start with this message:

> Use the publish-mobile-app skill to check this project and my computer, build the app,
> and run it in a simulator or emulator. Explain progress in plain language.
> Tell me what remains before store submission; do not upload or publish yet.

AGENTS.md contains the shared project instructions; CLAUDE.md imports them for Claude Code.
The publish-mobile-app and set-app-identity skills are included under both .agents/skills and
.claude/skills. These folders are hidden in Finder; press Command-Shift-period to show them.
No separate skill download is needed. You can also follow the manual build steps below.

## Project details

Application: Business Entrepreneur 
Application ID: com.example.portal.app262654410770455
Portal: https://app.jotform.com/angelvenicebondilles/business-entrepreneur?portalMobileExport=android

This source project opens the hosted public portal in a WebView using Capacitor 8.5.3.
It contains no APK, AAB, IPA, signing key, certificate, or publisher account.
Native compilation and device behavior must be verified in your environment.

This project uses Capacitor server.url, which is documented for live reload and is not intended for production.
Treat this hosted WebView export as a prototype and review the production architecture and store requirements
before release.
https://capacitorjs.com/docs/config

Install Node.js 22 or newer and extract the ZIP.
Open a terminal in the extracted project folder containing package.json and capacitor.config.json.
Run the commands in the platform section below from this folder.

The package lock pins the dependencies.
Keep this application ID and the appropriate signing identity for future updates.
Portal URL changes require npm run sync before rebuilding. Before publishing updates, increase the native version
and build numbers in Android Studio or Xcode. No session from your desktop browser is included.

## Android

Install Android Studio 2025.2.1 or newer, JDK 21, Android SDK Platform 36, and Build Tools 36.0.0.
Set the Gradle JDK to 21. The included Gradle version does not support running on Java 25.

Run these commands to install dependencies and open Android Studio:

```sh
npm ci
npm run open:android
```

For manual opening, choose Open in Android Studio and select the android folder inside this project.
Allow Gradle sync and install missing SDK components. npm ci is required because Gradle references
node_modules/@capacitor/android/capacitor. On macOS or Linux, run chmod +x android/gradlew
if your ZIP extractor removes executable permissions.

Use an emulator or connected Android 7+ device for testing.
Android Studio Run uses your local debug signing identity. For release, use Build > Generate Signed Bundle/APK
and your own keystore. Publish through your own developer account.

You can also run npm run android:unsigned to compile unsigned release APK and AAB files on macOS or Linux.
On Windows, run gradlew.bat assembleRelease bundleRelease from the android folder instead.
The outputs are under android/app/build/outputs. An unsigned APK cannot be installed.
An AAB cannot be installed directly, even after signing. Sign APKs with apksigner and AABs with jarsigner,
or use Android Studio. Preserve your app-signing key for sideload updates; Google Play upload keys
and app-signing keys have different roles.

https://developer.android.com/studio/publish/app-signing
https://developer.android.com/build/building-cmdline
