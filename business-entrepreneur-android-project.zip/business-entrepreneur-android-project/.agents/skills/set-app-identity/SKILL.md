---
name: set-app-identity
description: Change this app's store name and Application ID safely, before the first store upload.
---

1. Ask the user for the new app name and the new Application ID (reverse-domain, e.g. com.mybusiness.myapp).
2. Warn that the ID can't change after the first store upload.
3. Update every place the ID and name appear: capacitor.config.json, the native project files
   (android/app/build.gradle, MainActivity.java package and folder, strings.xml).
4. Run `npx cap sync android` and build once to confirm.
5. Tell the user that a new download from Jotform starts with the default name and ID again,
   and that you (or this skill) will set them back before the next upload.
