---
name: publish-mobile-app
description: Build, run, troubleshoot, and prepare this exported Jotform mobile project for Google Play or the App Store. Use for local setup, simulator or emulator testing, signing, and store preparation.
---

# Prepare this mobile app

Read the project's root AGENTS.md and README.md first. Work from the extracted folder containing
package.json and capacitor.config.json. Use only the native platform included in this ZIP.
The same skill is packaged for Codex and Claude; do not run both copies.

## Start at the requested stage

Determine whether the user wants a local preview, a build, or store preparation, and whether this
is a new app or an update to an existing listing. Use information already provided. Explain progress
in plain language and carry out authorized local work; wait when the next step needs the user's action.
A successful local test completes a preview request. It does not authorize signing or uploading.

## Set up and build

1. Check the installed Node.js and native tools against README.md before installing anything.
   Keep the locked Capacitor versions and native dependency configuration. Run npm ci from the project root.
2. For iOS, use macOS and full Xcode with a simulator runtime. Open ios/App/App.xcodeproj using
   npm run open:ios, select the App scheme and a simulator, then build and run. This export uses
   Swift Package Manager; do not add CocoaPods. A simulator build can run without release signing.
3. For Android, use the README's JDK and SDK versions. Open the android folder with
   npm run open:android, let Gradle sync, then run the debug app on an emulator or test device.
   Use the included Gradle wrapper; an unsigned release APK or an AAB is not an installable preview.
4. If a command fails, inspect its first actionable error and fix that cause. Check missing tools,
   dependency downloads, SDK/JDK selection and signing destination before changing project code.
   Rebuild after a fix; report an unresolved blocker instead of claiming success.

## Verify the running app

Launch the installed app and check that its live Jotform content loads, not just the splash screen.
For a full app test, exercise relevant navigation, forms and external links using test data with the
user's authorization. Desktop browser login is not carried into the native WebView. If loading fails,
check the configured URL, public access and network errors without making a private app public.
Report build success separately from observed runtime behavior and name any untested flows.

## Prepare a store release when requested

- Read README.md's hosted WebView limitation before proceeding. Review the current official store
  and Capacitor links in AGENTS.md with the user; compiling is not proof of production readiness
  or store acceptance. Explain any unresolved architecture or policy requirement before uploading.
- Use the sibling set-app-identity skill before changing the name or Application ID. For an existing
  listing, preserve its identifier and signing continuity. For a new listing, get the user's own
  identifier; do not publish the generated com.example placeholder. Sync and rebuild after changes.
- Check native version/build numbers, icons, launch appearance and the app's actual data collection
  before preparing screenshots, privacy disclosures and listing details. Do not invent declarations.
- Use the user's Apple team/provisioning or Android keystore and developer account. Do not ask for
  passwords or signing secrets in chat, include them in the ZIP, or overwrite existing signing keys.
  Guide the user through account, payment and agreement steps in the official tools.
- Prepare and verify the signed artifact before a requested upload. Obtain explicit authorization
  for the destination and release action if it has not already been given. Upload, review submission
  and public release are separate outcomes; report only the one actually completed.

## Finish

State the artifact path, target device/platform, checks that passed and the next unresolved step.
Keep any chosen identity and signing setup for future updates: a fresh Jotform export starts with
the generated defaults again. Never present a simulator build as a signed store release.
