package com.example.portal.app262654410770455;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
